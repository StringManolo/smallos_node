
# Created by ./configureAlpine.sh

echo -e "nameserver 1.1.1.1\nnameserver 1.0.0.1" > /etc/resolv.conf
rm /etc/profile.d/setup.sh



